# Complaints_Project

Problem Statement

US government identified that the number of complaints from customers holding accounts in the
different banks increased dramatically in last few years

To help the government understand and also improve the services in future, they have asked us to
develop an application to help them analyse the common trends and issues customers faced based on
historical data shared with us.
